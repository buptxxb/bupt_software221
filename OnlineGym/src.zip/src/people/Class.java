package people;

public class Class {
    public int id;
    public String coach;
    public String duration;
}
