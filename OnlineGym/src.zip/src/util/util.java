package util;

import java.util.*;

public class util {
    public static int GLOBALID;
    public static String GLOBALNAME;
    public static String GLOBALSEARCH;
    public static String GLOBALTYPE;
}
