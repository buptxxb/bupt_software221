package scheduletable;

public class scheduletable {
    private String ClassSun1;
    private String ClassSun2;
    private String ClassSun3;
    private String ClassSun4;
    private String ClassSun5;
    private String ClassSun6;

    private String ClassMon1;
    private String ClassMon2;
    private String ClassMon3;
    private String ClassMon4;
    private String ClassMon5;
    private String ClassMon6;

    private String ClassTue1;
    private String ClassTue2;
    private String ClassTue3;
    private String ClassTue4;
    private String ClassTue5;
    private String ClassTue6;

    private String ClassWed1;
    private String ClassWed2;
    private String ClassWed3;
    private String ClassWed4;
    private String ClassWed5;
    private String ClassWed6;

    private String ClassThu1;
    private String ClassThu2;
    private String ClassThu3;
    private String ClassThu4;
    private String ClassThu5;
    private String ClassThu6;

    private String ClassFri1;
    private String ClassFri2;
    private String ClassFri3;
    private String ClassFri4;
    private String ClassFri5;
    private String ClassFri6;

    private String ClassSat1;
    private String ClassSat2;
    private String ClassSat3;
    private String ClassSat4;
    private String ClassSat5;
    private String ClassSat6;



    public scheduletable(String ClassSun1){
        this.ClassSun1 = ClassSun1;
        this.ClassSun2 = ClassSun2;
        this.ClassSun3 = ClassSun3;
        this.ClassSun4 = ClassSun4;
        this.ClassSun5 = ClassSun5;
        this.ClassSun6 = ClassSun6;

        this.ClassMon1 = ClassMon1;
        this.ClassMon2 = ClassMon2;
        this.ClassMon3 = ClassMon3;
        this.ClassMon4 = ClassMon4;
        this.ClassMon5 = ClassMon5;
        this.ClassMon6 = ClassMon6;

        this.ClassTue1 = ClassTue1;
        this.ClassTue2 = ClassTue2;
        this.ClassTue3 = ClassTue3;
        this.ClassTue4 = ClassTue4;
        this.ClassTue5 = ClassTue5;
        this.ClassTue6 = ClassTue6;

        this.ClassWed1 = ClassWed1;
        this.ClassWed2 = ClassWed2;
        this.ClassWed3 = ClassWed3;
        this.ClassWed4 = ClassWed4;
        this.ClassWed5 = ClassWed5;
        this.ClassWed6 = ClassWed6;

        this.ClassThu1 = ClassThu1;
        this.ClassThu2 = ClassThu2;
        this.ClassThu3 = ClassThu3;
        this.ClassThu4 = ClassThu4;
        this.ClassThu5 = ClassThu5;
        this.ClassThu6 = ClassThu6;

        this.ClassFri1 = ClassFri1;
        this.ClassFri2 = ClassFri2;
        this.ClassFri3 = ClassFri3;
        this.ClassFri4 = ClassFri4;
        this.ClassFri5 = ClassFri5;
        this.ClassFri6 = ClassFri6;

        this.ClassSat1 = ClassSat1;
        this.ClassSat2 = ClassSat2;
        this.ClassSat3 = ClassSat3;
        this.ClassSat4 = ClassSat4;
        this.ClassSat5 = ClassSat5;
        this.ClassSat6 = ClassSat6;
}
}
